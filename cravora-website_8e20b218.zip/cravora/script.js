/* ============================================================
   Cravora — Interactive scripts (menu + cart + checkout)
   ============================================================ */

/* ---------- Menu data ---------- */
const MENU = {
  pizza: [
    { id: "pz01", name: "Margherita Classic",        desc: "San Marzano tomato, buffalo mozzarella, fresh basil.",      price: 899,  img: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "pz02", name: "Pepperoni Fiesta",          desc: "Double pepperoni, mozzarella, oregano, chili honey drizzle.", price: 1199, img: "https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=600&q=80" },
    { id: "pz03", name: "Chicken Tikka Pizza",       desc: "Desi tikka chicken, red onion, capsicum, mint yogurt.",     price: 1099, img: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "pz04", name: "BBQ Chicken Ranch",         desc: "Smoky BBQ sauce, grilled chicken, ranch, red onion.",       price: 1249, img: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80" },
    { id: "pz05", name: "Four Cheese Blend",         desc: "Mozzarella, cheddar, parmesan, feta on white base.",        price: 1299, img: "https://images.unsplash.com/photo-1594007654729-407eedc4be65?auto=format&fit=crop&w=600&q=80" },
    { id: "pz06", name: "Fajita Chicken Pizza",      desc: "Grilled fajita chicken, bell peppers, jalapeño, cheese.",   price: 1249, img: "https://images.unsplash.com/photo-1571407970349-bc81e7e96d47?auto=format&fit=crop&w=600&q=80" },
    { id: "pz07", name: "Veggie Supreme",            desc: "Mushroom, olives, corn, capsicum, onion, tomato.",          price: 999,  img: "https://images.unsplash.com/photo-1585238342024-78d387f4a707?auto=format&fit=crop&w=600&q=80" },
    { id: "pz08", name: "Beef & Jalapeño",           desc: "Seasoned beef, spicy jalapeño, red onion, mozzarella.",     price: 1349, img: "https://images.unsplash.com/photo-1548369937-47519962c11a?auto=format&fit=crop&w=600&q=80" },
    { id: "pz09", name: "Truffle Mushroom",          desc: "White base, wild mushroom, truffle oil, arugula.",          price: 1599, img: "https://images.unsplash.com/photo-1600628421055-4d30de868b8f?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "pz10", name: "Cravora Signature XL",      desc: "Chicken, beef, pepperoni, sausage, extra cheese — 16 inch.", price: 1899, img: "https://images.unsplash.com/photo-1590947132387-155cc02f3212?auto=format&fit=crop&w=600&q=80" }
  ],
  burgers: [
    { id: "bg01", name: "Cravora Classic Burger",    desc: "Angus beef, cheddar, lettuce, tomato, house sauce.",        price: 799,  img: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "bg02", name: "Double Cheese Beast",       desc: "Two beef patties, double cheddar, pickles, mustard mayo.",  price: 1099, img: "https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=600&q=80" },
    { id: "bg03", name: "Crispy Chicken Zinger",     desc: "Crunchy chicken fillet, coleslaw, lettuce, spicy mayo.",    price: 749,  img: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?auto=format&fit=crop&w=600&q=80" },
    { id: "bg04", name: "BBQ Bacon Burger",          desc: "Beef patty, crispy bacon, cheddar, onion rings, BBQ.",      price: 1149, img: "https://images.unsplash.com/photo-1553979459-d2229ba7433b?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "bg05", name: "Mushroom Swiss Burger",     desc: "Beef patty, sautéed mushrooms, swiss cheese, garlic aioli.", price: 999,  img: "https://images.unsplash.com/photo-1596662951482-0c4ba74a6df6?auto=format&fit=crop&w=600&q=80" },
    { id: "bg06", name: "Spicy Jalapeño Burger",     desc: "Chicken/beef, jalapeño, pepper jack, chipotle sauce.",      price: 899,  img: "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?auto=format&fit=crop&w=600&q=80" },
    { id: "bg07", name: "Cravora Mega Stack",        desc: "Triple beef, triple cheese, bacon, egg, onion rings.",      price: 1499, img: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?auto=format&fit=crop&w=600&q=80" },
    { id: "bg08", name: "Veggie Delight Burger",     desc: "Grilled veggie patty, avocado, lettuce, sun-dried tomato.", price: 749,  img: "https://images.unsplash.com/photo-1520072959219-c595dc870360?auto=format&fit=crop&w=600&q=80" }
  ],
  shawarma: [
    { id: "sh01", name: "Chicken Shawarma Roll",     desc: "Grilled chicken, garlic sauce, pickles, fries in pita.",    price: 449,  img: "https://images.unsplash.com/photo-1662116765994-1e4200c74589?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "sh02", name: "Beef Shawarma Roll",        desc: "Slow-marinated beef, tahini, tomato, onion in pita.",       price: 549,  img: "https://images.unsplash.com/photo-1633321702518-7feccafb94d5?auto=format&fit=crop&w=600&q=80" },
    { id: "sh03", name: "Mix Shawarma Roll",         desc: "Chicken + beef combo, double sauce, cheese slice.",         price: 599,  img: "https://images.unsplash.com/photo-1561651823-34feb02250e4?auto=format&fit=crop&w=600&q=80" },
    { id: "sh04", name: "Cheesy Chicken Shawarma",   desc: "Chicken, mozzarella, garlic mayo — melted & wrapped.",      price: 549,  img: "https://images.unsplash.com/photo-1550304943-4f24f54ddde9?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "sh05", name: "Shawarma Platter",          desc: "Shawarma meat, rice, salad, hummus, garlic sauce, pita.",   price: 999,  img: "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?auto=format&fit=crop&w=600&q=80" },
    { id: "sh06", name: "Zinger Shawarma",           desc: "Crispy chicken zinger inside a shawarma wrap.",             price: 599,  img: "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=600&q=80" },
    { id: "sh07", name: "Family Shawarma Box",       desc: "4 rolls + fries + 1.5L drink — feeds 4.",                   price: 1899, img: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80" }
  ],
  pasta: [
    { id: "pa01", name: "Chicken Alfredo",           desc: "Fettuccine, creamy alfredo, grilled chicken, parmesan.",    price: 899,  img: "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "pa02", name: "Spaghetti Bolognese",       desc: "Slow-cooked beef ragù, tomato, herbs, parmesan.",           price: 999,  img: "https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?auto=format&fit=crop&w=600&q=80" },
    { id: "pa03", name: "Pink Sauce Pasta",          desc: "Penne in tomato-cream sauce, chicken, chili flakes.",       price: 849,  img: "https://images.unsplash.com/photo-1473093226795-af9932fe5856?auto=format&fit=crop&w=600&q=80" },
    { id: "pa04", name: "Pesto Chicken Penne",       desc: "Basil pesto, grilled chicken, cherry tomato, pine nuts.",   price: 999,  img: "https://images.unsplash.com/photo-1563379926898-05f4575a45d8?auto=format&fit=crop&w=600&q=80" },
    { id: "pa05", name: "Prawn Aglio e Olio",        desc: "Spaghetti, garlic, chili, olive oil, jumbo prawns.",        price: 1299, img: "https://images.unsplash.com/photo-1608219992759-35cbef4142e2?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "pa06", name: "Lasagna al Forno",          desc: "Layered pasta, beef ragù, béchamel, mozzarella baked.",     price: 1099, img: "https://images.unsplash.com/photo-1619895092538-128f4d2d0d81?auto=format&fit=crop&w=600&q=80" },
    { id: "pa07", name: "Truffle Mushroom Pasta",    desc: "Fettuccine, wild mushrooms, truffle oil, parmesan.",        price: 1199, img: "https://images.unsplash.com/photo-1633436375153-d7045cb93e38?auto=format&fit=crop&w=600&q=80" },
    { id: "pa08", name: "Arrabbiata Spicy Penne",    desc: "Fiery tomato, garlic, chili — for spice lovers.",           price: 749,  img: "https://images.unsplash.com/photo-1598866594230-a7c12756260f?auto=format&fit=crop&w=600&q=80" }
  ],
  macaroni: [
    { id: "mc01", name: "Chicken Mac & Cheese",      desc: "Elbow macaroni, cheddar sauce, grilled chicken chunks.",     price: 699,  img: "https://images.unsplash.com/photo-1543339308-43e59d6b73a6?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "mc02", name: "Baked Mac & Cheese",        desc: "Oven-baked with breadcrumb crust, 3-cheese blend.",         price: 849,  img: "https://images.unsplash.com/photo-1621996659490-3275b4d0d951?auto=format&fit=crop&w=600&q=80" },
    { id: "mc03", name: "Chili Beef Macaroni",       desc: "Macaroni, spicy beef mince, tomato, kidney beans.",         price: 799,  img: "https://images.unsplash.com/photo-1607330289024-1535c6b4e1c1?auto=format&fit=crop&w=600&q=80" },
    { id: "mc04", name: "Desi Chicken Macaroni",     desc: "Pakistani-style, tikka spice, capsicum, onion, ketchup.",   price: 649,  img: "https://images.unsplash.com/photo-1546549032-9571cd6b27df?auto=format&fit=crop&w=600&q=80", pick: true },
    { id: "mc05", name: "Creamy Vegetable Macaroni", desc: "White sauce, mixed veggies, corn, herbs.",                  price: 599,  img: "https://images.unsplash.com/photo-1611270629569-8b357cb88da9?auto=format&fit=crop&w=600&q=80" },
    { id: "mc06", name: "BBQ Chicken Macaroni",      desc: "Macaroni tossed in smoky BBQ sauce with grilled chicken.",  price: 749,  img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80" }
  ]
};

/* ---------- Cart state ---------- */
let cart = JSON.parse(localStorage.getItem('cravora_cart') || '[]');

/* ---------- Render menu ---------- */
function renderMenu(category) {
  const grid = document.getElementById('menu-grid');
  const items = MENU[category] || [];
  grid.innerHTML = items.map((item, i) => `
    <article class="menu-item" style="animation-delay:${i * 60}ms">
      <div class="menu-item-img">
        <img src="${item.img}" alt="${item.name}" loading="lazy" onerror="this.style.display='none'" />
        ${item.pick ? '<span class="pick-badge">Chef\'s Pick</span>' : ''}
      </div>
      <div class="menu-item-body">
        <div class="menu-item-head">
          <h3>${item.name}</h3>
          <span class="price">Rs. ${item.price}</span>
        </div>
        <p>${item.desc}</p>
        <button class="add-btn" onclick="addToCart('${item.id}','${category}')">
          <span class="add-icon">+</span> Add to Cart
        </button>
      </div>
    </article>
  `).join('');
}

/* ---------- Menu tabs ---------- */
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    renderMenu(tab.dataset.tab);
  });
});
renderMenu('pizza');

/* ---------- Cart functions ---------- */
function findItem(id) {
  for (const cat in MENU) {
    const found = MENU[cat].find(i => i.id === id);
    if (found) return found;
  }
  return null;
}

function addToCart(id, category) {
  const item = findItem(id);
  if (!item) return;
  const existing = cart.find(c => c.id === id);
  if (existing) existing.qty += 1;
  else cart.push({ id, name: item.name, price: item.price, img: item.img, qty: 1 });
  saveCart();
  bumpCartBadge();
  toast(`✓ ${item.name} added`);
}

function updateQty(id, delta) {
  const item = cart.find(c => c.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(c => c.id !== id);
  saveCart();
  renderCart();
}

function removeItem(id) {
  cart = cart.filter(c => c.id !== id);
  saveCart();
  renderCart();
}

function saveCart() {
  localStorage.setItem('cravora_cart', JSON.stringify(cart));
  updateCartCount();
}

function cartTotal() {
  return cart.reduce((s, i) => s + i.price * i.qty, 0);
}

function updateCartCount() {
  const count = cart.reduce((s, i) => s + i.qty, 0);
  document.querySelectorAll('.cart-count').forEach(el => {
    el.textContent = count;
    el.style.display = count > 0 ? 'flex' : 'none';
  });
}

function bumpCartBadge() {
  document.querySelectorAll('.cart-count').forEach(el => {
    el.classList.remove('bump');
    void el.offsetWidth;
    el.classList.add('bump');
  });
}

/* ---------- Cart drawer ---------- */
function openCart() {
  renderCart();
  document.getElementById('cart-drawer').classList.add('open');
  document.getElementById('overlay').classList.add('show');
  document.body.style.overflow = 'hidden';
}

function closeCart() {
  document.getElementById('cart-drawer').classList.remove('open');
  document.getElementById('overlay').classList.remove('show');
  document.body.style.overflow = '';
}

function renderCart() {
  const body = document.getElementById('cart-body');
  const footer = document.getElementById('cart-footer');
  if (cart.length === 0) {
    body.innerHTML = `
      <div class="cart-empty">
        <div class="cart-empty-icon">🍽️</div>
        <h3>Your cart is empty</h3>
        <p>Add some delicious food from the menu!</p>
        <button class="btn btn-primary" onclick="closeCart(); document.getElementById('menu').scrollIntoView({behavior:'smooth'})">Browse Menu</button>
      </div>`;
    footer.style.display = 'none';
    return;
  }
  body.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img src="${item.img}" alt="${item.name}" onerror="this.style.background='#eee'" />
      <div class="cart-item-info">
        <h4>${item.name}</h4>
        <span class="cart-item-price">Rs. ${item.price}</span>
        <div class="qty-control">
          <button onclick="updateQty('${item.id}',-1)">−</button>
          <span>${item.qty}</span>
          <button onclick="updateQty('${item.id}',1)">+</button>
        </div>
      </div>
      <div class="cart-item-total">
        <span>Rs. ${item.price * item.qty}</span>
        <button class="remove-btn" onclick="removeItem('${item.id}')" aria-label="Remove">✕</button>
      </div>
    </div>
  `).join('');

  const subtotal = cartTotal();
  const delivery = subtotal >= 1500 ? 0 : 150;
  const total = subtotal + delivery;
  footer.style.display = 'block';
  footer.innerHTML = `
    <div class="cart-summary">
      <div><span>Subtotal</span><strong>Rs. ${subtotal}</strong></div>
      <div><span>Delivery</span><strong>${delivery === 0 ? 'FREE 🎉' : 'Rs. ' + delivery}</strong></div>
      ${subtotal < 1500 ? `<p class="free-hint">Add Rs. ${1500 - subtotal} more for FREE delivery</p>` : ''}
      <div class="cart-total"><span>Total</span><strong>Rs. ${total}</strong></div>
    </div>
    <button class="btn btn-primary btn-full" onclick="openCheckout()">Proceed to Checkout →</button>
  `;
}

/* ---------- Checkout ---------- */
function openCheckout() {
  if (cart.length === 0) return;
  closeCart();
  const modal = document.getElementById('checkout-modal');
  modal.classList.add('open');
  document.getElementById('overlay').classList.add('show');
  document.body.style.overflow = 'hidden';
  updateCheckoutSummary();
}

function closeCheckout() {
  document.getElementById('checkout-modal').classList.remove('open');
  document.getElementById('overlay').classList.remove('show');
  document.body.style.overflow = '';
}

function updateCheckoutSummary() {
  const subtotal = cartTotal();
  const delivery = subtotal >= 1500 ? 0 : 150;
  const total = subtotal + delivery;
  document.getElementById('co-items').innerHTML = cart.map(i =>
    `<div class="co-line"><span>${i.qty}× ${i.name}</span><span>Rs. ${i.price * i.qty}</span></div>`
  ).join('');
  document.getElementById('co-subtotal').textContent = 'Rs. ' + subtotal;
  document.getElementById('co-delivery').textContent = delivery === 0 ? 'FREE' : 'Rs. ' + delivery;
  document.getElementById('co-total').textContent = 'Rs. ' + total;
}

/* ---------- Place order ---------- */
function placeOrder(e) {
  e.preventDefault();
  const f = e.target;
  const orderType = f.orderType.value;
  const payment = f.payment.value;
  const subtotal = cartTotal();
  const delivery = orderType === 'pickup' ? 0 : (subtotal >= 1500 ? 0 : 150);
  const total = subtotal + delivery;

  const itemsText = cart.map(i => `• ${i.qty}× ${i.name} — Rs. ${i.price * i.qty}`).join('%0A');

  let paymentLabel = {
    cod: '💵 Cash on Delivery',
    jazzcash: '📱 JazzCash',
    easypaisa: '📱 EasyPaisa',
    bank: '🏦 Bank Transfer',
    card: '💳 Card (link will be sent)'
  }[payment];

  const msg =
    `🍕 *NEW ORDER — CRAVORA*%0A%0A` +
    `👤 *Name:* ${f.customerName.value}%0A` +
    `📞 *Phone:* ${f.customerPhone.value}%0A` +
    `📍 *Type:* ${orderType === 'delivery' ? 'Delivery' : 'Pickup'}%0A` +
    (orderType === 'delivery' ? `🏠 *Address:* ${f.address.value}%0A` : '') +
    `%0A🛒 *Items:*%0A${itemsText}%0A%0A` +
    `Subtotal: Rs. ${subtotal}%0A` +
    `Delivery: ${delivery === 0 ? 'FREE' : 'Rs. ' + delivery}%0A` +
    `*Total: Rs. ${total}*%0A%0A` +
    `💳 *Payment:* ${paymentLabel}%0A` +
    (f.notes.value ? `📝 *Notes:* ${f.notes.value}%0A` : '');

  // *** REPLACE THIS WITH YOUR ACTUAL WHATSAPP NUMBER ***
  const whatsappNumber = '923001234567';
  const url = `https://wa.me/${whatsappNumber}?text=${msg}`;

  // Show success animation
  document.getElementById('checkout-modal').classList.remove('open');
  const success = document.getElementById('success-modal');
  success.classList.add('open');
  document.getElementById('order-total').textContent = 'Rs. ' + total;

  // Open WhatsApp
  setTimeout(() => window.open(url, '_blank'), 800);

  // Show payment instructions if not COD
  const instructionEl = document.getElementById('payment-instruction');
  if (payment === 'jazzcash') {
    instructionEl.innerHTML = `
      <h4>📱 JazzCash Payment</h4>
      <p>Send <strong>Rs. ${total}</strong> to:</p>
      <div class="pay-box">03XX-XXXXXXX<br><small>Account title: Cravora Restaurant</small></div>
      <p>Share screenshot on WhatsApp to confirm order.</p>`;
  } else if (payment === 'easypaisa') {
    instructionEl.innerHTML = `
      <h4>📱 EasyPaisa Payment</h4>
      <p>Send <strong>Rs. ${total}</strong> to:</p>
      <div class="pay-box">03XX-XXXXXXX<br><small>Account title: Cravora Restaurant</small></div>
      <p>Share screenshot on WhatsApp to confirm order.</p>`;
  } else if (payment === 'bank') {
    instructionEl.innerHTML = `
      <h4>🏦 Bank Transfer</h4>
      <p>Transfer <strong>Rs. ${total}</strong> to:</p>
      <div class="pay-box">Bank: HBL<br>Account: 12345-6789012-345<br>Title: Cravora Restaurant</div>
      <p>Share receipt on WhatsApp to confirm order.</p>`;
  } else if (payment === 'card') {
    instructionEl.innerHTML = `
      <h4>💳 Card Payment</h4>
      <p>A secure payment link for <strong>Rs. ${total}</strong> will be sent to your WhatsApp within 2 minutes.</p>`;
  } else {
    instructionEl.innerHTML = `
      <h4>💵 Cash on Delivery</h4>
      <p>Please keep <strong>Rs. ${total}</strong> ready. Our rider will arrive in 30-45 minutes.</p>`;
  }

  // Clear cart
  cart = [];
  saveCart();
  f.reset();
}

function closeSuccess() {
  document.getElementById('success-modal').classList.remove('open');
  document.getElementById('overlay').classList.remove('show');
  document.body.style.overflow = '';
}

/* ---------- Toast ---------- */
function toast(text) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = text;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('show'), 10);
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 300); }, 2000);
}

/* ---------- Reservation form → WhatsApp ---------- */
function handleReserve(e) {
  e.preventDefault();
  const f = e.target;
  const msg =
    `Hi Cravora! Reservation request:%0A%0A` +
    `👤 Name: ${f.name.value}%0A` +
    `📞 Phone: ${f.phone.value}%0A` +
    `👥 Guests: ${f.guests.value}%0A` +
    `📅 Date: ${f.date.value}%0A` +
    `⏰ Time: ${f.time.value}%0A` +
    (f.notes.value ? `📝 Notes: ${f.notes.value}%0A` : '');
  const whatsappNumber = '923001234567';
  window.open(`https://wa.me/${whatsappNumber}?text=${msg}`, '_blank');
  toast('✓ Reservation sent to WhatsApp');
  f.reset();
}

/* ---------- Order type toggle ---------- */
document.addEventListener('change', (e) => {
  if (e.target.name === 'orderType') {
    const addrField = document.getElementById('address-field');
    if (e.target.value === 'pickup') {
      addrField.style.display = 'none';
      addrField.querySelector('textarea').required = false;
    } else {
      addrField.style.display = 'block';
      addrField.querySelector('textarea').required = true;
    }
    updateCheckoutSummary();
  }
});

/* ---------- Nav scroll ---------- */
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 20);
});

/* ---------- Mobile menu close ---------- */
document.querySelectorAll('.nav-links a').forEach(a => {
  a.addEventListener('click', () => document.body.classList.remove('menu-open'));
});

/* ---------- Date min ---------- */
const dateInput = document.querySelector('input[type="date"]');
if (dateInput) {
  const today = new Date().toISOString().split('T')[0];
  dateInput.min = today;
  dateInput.value = today;
}

/* ---------- Reveal-on-scroll ---------- */
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('reveal-in');
      io.unobserve(e.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal, .section-head, .about-content, .about-image, .signature-content, .signature-image, blockquote, .contact-grid > *').forEach(el => {
  el.classList.add('reveal');
  io.observe(el);
});

/* ---------- Init ---------- */
updateCartCount();
