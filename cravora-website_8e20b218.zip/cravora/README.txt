================================================================
  CRAVORA — Complete Restaurant Website
  Full A-to-Z code with Online Ordering + Payment System
================================================================

FILES IN THIS FOLDER
--------------------
  index.html    →  Main website (all pages in one)
  styles.css    →  Complete design + animations
  script.js     →  Menu, cart, checkout, payment logic
  README.txt    →  This deployment guide

TOTAL SIZE: ~50 KB — super fast, mobile-friendly.


================================================================
  WEBSITE FEATURES
================================================================

MENU CATEGORIES (45+ items):
  🍕 Pizza     — 10 varieties (Margherita, Pepperoni, Chicken Tikka,
                  BBQ Ranch, Four Cheese, Fajita, Veggie Supreme,
                  Beef Jalapeño, Truffle Mushroom, Signature XL)
  🍔 Burgers   — 8 types (Classic, Double Cheese, Zinger,
                  BBQ Bacon, Mushroom Swiss, Jalapeño, Mega Stack, Veggie)
  🌯 Shawarma  — 7 types (Chicken, Beef, Mix, Cheesy, Platter,
                  Zinger, Family Box)
  🍝 Pasta     — 8 dishes (Alfredo, Bolognese, Pink Sauce, Pesto,
                  Aglio e Olio, Lasagna, Truffle, Arrabbiata)
  🧀 Macaroni  — 6 varieties (Mac & Cheese, Baked, Chili Beef,
                  Desi Chicken, Vegetable, BBQ)

ORDERING SYSTEM:
  ✓ Add to Cart from menu (with images)
  ✓ Cart drawer (slides in from right)
  ✓ Quantity +/- controls
  ✓ Live total calculation
  ✓ FREE delivery over Rs. 1,500
  ✓ Delivery / Pickup toggle
  ✓ Full checkout modal with customer details
  ✓ Order sent to owner's WhatsApp automatically

PAYMENT METHODS:
  💵 Cash on Delivery
  📱 JazzCash
  📱 EasyPaisa
  🏦 Bank Transfer
  💳 Credit/Debit Card (link via WhatsApp)

ANIMATIONS:
  ✓ Fade-up hero text
  ✓ Floating particles
  ✓ Pulsing WhatsApp button
  ✓ Card hover lifts
  ✓ Cart badge bump
  ✓ Slide-in cart items
  ✓ Modal scale animation
  ✓ Animated success checkmark
  ✓ Reveal-on-scroll for sections
  ✓ Toast notifications


================================================================
  STEP 1 — DOMAIN KHAREEDNA
================================================================

Suggested platforms:
  - Namecheap.com    (recommended, ~$10/year)
  - Hostinger.com    (Pakistan support)
  - GoDaddy.com

Suggested names:
  - cravora.com  |  cravora.pk  |  cravora.cafe
  - eatcravora.com  |  cravora.co


================================================================
  STEP 2 — HOSTING KHAREEDNA
================================================================

Ye 100% static site hai. Kisi bhi hosting par chalegi.

PAID (Rs. 500-800/month):
  A) Hostinger Premium (~$3/month) — Recommended
  B) Namecheap Stellar (~$2/month)
  C) Bluehost Basic (~$3/month)

FREE OPTIONS (no credit card needed):
  A) Netlify.com          — drag & drop (EASIEST)
  B) Vercel.com           — GitHub connect
  C) Cloudflare Pages     — fastest CDN
  D) GitHub Pages         — free with GitHub


================================================================
  STEP 3 — WEBSITE UPLOAD
================================================================

METHOD 1 — cPanel Hosting (traditional):
------------------------------------------
1. cPanel mein login karein
2. "File Manager" → "public_html" folder open karein
3. Upload button dabayein
4. Ye 3 files upload karein:
     - index.html
     - styles.css
     - script.js
5. Ho gaya — website apne domain par live!

METHOD 2 — Netlify (FREE, easiest, 30 seconds):
------------------------------------------------
1. netlify.com par sign up (free)
2. "Add new site" → "Deploy manually"
3. Ye poora folder (cravora/) drag & drop karein
4. Live URL milega jaise: cravora-xyz.netlify.app
5. Free custom domain bhi connect kar sakte hain

METHOD 3 — GitHub Pages (FREE):
--------------------------------
1. GitHub par repo banayein
2. 3 files upload karein
3. Settings → Pages → Deploy from main branch
4. URL: username.github.io/repo-name


================================================================
  STEP 4 — CUSTOMIZATION (ZAROORI!)
================================================================

Website live karnay se PEHLE ye cheezein zaroor badlein:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. WHATSAPP NUMBER (sub se important!)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Open: script.js
Search: 923001234567 (3 jagah hai)
Replace: apna WhatsApp number
Format: country code + number (no + or spaces)
Example: '923331234567' (agar aap ka number 0333-1234567 hai)

Also in index.html: search "923001234567" and replace.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2. PAYMENT ACCOUNT DETAILS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Open: script.js
Search: "03XX-XXXXXXX"
Replace: apna actual JazzCash/EasyPaisa number

Search: "12345-6789012-345"
Replace: apna bank account number

Search: "Bank: HBL"
Replace: apna bank name

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3. RESTAURANT ADDRESS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Open: index.html
Search: "123 Zamzama Boulevard"
Replace: apna restaurant address

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4. PHONE / EMAIL
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Open: index.html
Search: "+92 300 1234567"  →  apna phone
Search: "hello@cravora.com" →  apna email

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
5. SOCIAL LINKS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Open: index.html
Search: aria-label="Instagram" (or Facebook, WhatsApp, TikTok)
Replace href="#" with your actual social page URLs

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
6. GOOGLE MAP (optional)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Currently uses OpenStreetMap (free, no API key).
Chahiye to Google Maps embed code use karein:
- Google Maps → Share → Embed a map → Copy iframe
- Replace iframe in "map-frame" section


================================================================
  STEP 5 — MENU CUSTOMIZATION (optional)
================================================================

Menu items ko add/edit/remove karne ke liye:

Open: script.js
Top par MENU object hai. Format:
    {
      id: "pz11",                      // unique id
      name: "Dish Name",
      desc: "Short description...",
      price: 999,                       // just number, in PKR
      img: "https://image-url.jpg",
      pick: true                        // optional — shows "Chef's Pick" badge
    }

To add new category:
  1. MENU object mein new key add karein
  2. index.html mein <button class="tab" data-tab="newkey"> add karein


================================================================
  HOW THE ORDER SYSTEM WORKS
================================================================

CUSTOMER JOURNEY:
  1. Customer browses menu, clicks "Add to Cart" on items
  2. Cart icon (top right) shows item count
  3. Customer opens cart → sees items, can change quantity
  4. Clicks "Proceed to Checkout"
  5. Fills form: Name, Phone, Address, Payment method
  6. Clicks "Place Order"

WHAT HAPPENS NEXT (automatic):
  → Success animation shown
  → WhatsApp opens automatically on customer's phone
  → Pre-filled message goes to YOUR WhatsApp with:
       - Full order details
       - Total amount
       - Payment method selected
       - Customer contact info
  → You confirm on WhatsApp → prepare food → deliver!

FOR PAID PAYMENT METHODS:
  Customer sees your JazzCash/EasyPaisa/Bank details on success screen.
  They send payment + screenshot to your WhatsApp → you confirm.


================================================================
  STEP 6 — UPGRADE OPTIONS (future)
================================================================

FOR AUTOMATED PAYMENTS (advanced):
  - Stripe (international cards)     — stripe.com
  - 2Checkout                         — 2checkout.com
  - PayFast (Pakistan)                — payfast.pk
  - SafePay (Pakistan)                — getsafepay.com

FOR RIDER TRACKING:
  Add Google Maps API for delivery tracking.

FOR ANALYTICS:
  Google Analytics — analytics.google.com (add before </body> tag)

FOR EMAIL RECEIPTS:
  Use FormSubmit.co or EmailJS to also send order to email.


================================================================
  TROUBLESHOOTING
================================================================

Q: Reservation/Order form kaam nahi kar raha?
A: WhatsApp number sahi format mein hona chahiye:
   ✓ '923001234567'  (country code + number)
   ✗ '+923001234567' (no +)
   ✗ '0300 1234567'  (no spaces)

Q: Images load nahi ho rahi?
A: All images are from Unsplash CDN. Internet connection check karein.
   Chahiye to apni images upload kar ke local URLs use karein.

Q: Cart items save nahi ho rahe?
A: Cart uses localStorage — private/incognito mode mein reset ho jayega.
   Normal mode mein perfectly work karega.


================================================================
  SUMMARY — Aap ke liye kya karna hai:
================================================================

  □ Step 1: Domain khareedein   (Namecheap ~Rs. 3000/year)
  □ Step 2: Hosting khareedein  (Hostinger ~Rs. 800/month)
             OR use FREE Netlify
  □ Step 3: script.js mein WhatsApp number aur payment
             details apni daalein
  □ Step 4: index.html mein address, phone, email badlein
  □ Step 5: 3 files upload karein hosting par
  □ DONE — Website live, orders WhatsApp par!


Enjoy your new food business — CRAVORA — Crave. Dine. Repeat. 🍕
================================================================
